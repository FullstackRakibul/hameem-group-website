<template>
  <footer class=" text-black py-10">
    <div class="container mx-auto px-4">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <!-- Contact Us Column -->
        <div>
          <div class="flex flex-col justify-center items-start h-full">
            <h2 class="text-2xl font-semibold mb-4">Contact Us</h2>
            <p class="mb-2">
              <strong>Head Office</strong><br />
              Ha-Meem Group<br />
              387 (South), Tejgaon Industrial Area<br />
              Dhaka-1208, Bangladesh
            </p>
            <p class="mb-2">
              <strong>Phone:</strong> +880-2-8170592, +880-2-8170593<br />
              <strong>Fax:</strong> +880-2-8170623
            </p>
          </div>
        </div>

        <!-- Map Column -->
        <div>
          <h2 class="text-2xl font-semibold mb-4">Our Location</h2>
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d773.4539053047216!2d90.39691218075808!3d23.758789222874693!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c7f36ebcbcdb%3A0x6363e2a5709dee2d!2sTML%20Building%20(Ha-Meem%20Group)!5e1!3m2!1sen!2sus!4v1737763612030!5m2!1sen!2sus"
            width="800" height="450" style="border:0;" allowfullscreen loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>
    </div>
  </footer>
</template>