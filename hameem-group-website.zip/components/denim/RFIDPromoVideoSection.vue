<template>
  <section class="container mx-auto">
    <el-row>
      <el-col :span="8" class="p-6 bg-gray-50">
        part 01
      </el-col>
      <el-col :span="16" class="p-6 bg-gray-50">
        part 02
      </el-col>
    </el-row>
  </section>
</template>