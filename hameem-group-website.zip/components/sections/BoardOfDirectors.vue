<template>
  <section class="container mx-auto">
        <!-- Section Title -->
    <el-row class="mb-10 justify-center">
      <el-col :span="24" class="text-center">
        <h2 class="text-4xl font-bold text-gray-800">Board Of Members</h2>
        <p class="text-lg text-gray-600 mt-2">
          Our milestones in excellence and recognition over the years.
        </p>
      </el-col>
    </el-row>
  </section>
</template>