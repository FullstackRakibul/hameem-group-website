<template>
  <section class=" bg-[url('/assets/HomePageBannerBG-01.jpg')] bg-cover bg-no-repeat ">
    <div
      class="container mx-auto flex flex-col justify-center items-center p-28">

      <el-image class="" style="max-width: 800px; width: 100%;" src="/assets/buyers-home.png" alt="Our's Buyer" />
    </div>
  </section>
</template>

<script lang="ts" setup>

</script>

<style scoped></style>