<template>
  <div class="h-screen w-screen flex items-center justify-center bg-purple-500 text-white">
    <h1 class="text-6xl font-bold">Slide Three</h1>
  </div>
</template>

<script setup>
</script>

<style scoped>
</style>
