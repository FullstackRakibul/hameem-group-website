<template>
  <div class="h-screen w-screen flex items-center justify-center bg-green-500 text-white">
    <h1 class="text-6xl font-bold">Slide Two</h1>
  </div>
</template>

<script setup>
</script>

<style scoped>
</style>
