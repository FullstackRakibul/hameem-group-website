<template>
  <div 
    class="mx-2 h-screen bg-cover bg-center flex flex-col justify-center items-center text-white"
    :style="{ backgroundImage: `url('./assets/home-banner-section-img-04.jpg')` }"
  >
    <div class="text-center md:text-left max-w-2xl px-4">
      <!-- <h2 class="text-4xl md:text-5xl font-bold text-primary">Denim Excellence</h2>
      <p class="text-lg md:text-xl mt-4 text-primary">Versatile designs for every occasion.</p> -->
    </div>
  </div>
</template>
